"""Seed intake helpers."""
