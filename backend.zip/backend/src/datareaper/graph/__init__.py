﻿"""Graph helpers."""
