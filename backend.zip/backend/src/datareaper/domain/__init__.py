﻿"""Domain objects and enums."""
