﻿"""Storage integrations."""
