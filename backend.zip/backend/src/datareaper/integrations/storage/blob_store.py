﻿from __future__ import annotations


def save_blob(name: str, content: bytes) -> dict:
    return {"name": name, "size": len(content)}
