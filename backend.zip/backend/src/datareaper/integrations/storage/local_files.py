﻿from __future__ import annotations

from pathlib import Path


def ensure_local_storage(root: str) -> str:
    Path(root).mkdir(parents=True, exist_ok=True)
    return root
