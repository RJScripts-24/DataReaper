﻿"""Jurisdiction policies."""
