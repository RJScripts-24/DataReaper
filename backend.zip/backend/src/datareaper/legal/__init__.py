﻿"""Legal package."""
