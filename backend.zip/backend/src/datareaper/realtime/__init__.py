"""Realtime delivery helpers."""
